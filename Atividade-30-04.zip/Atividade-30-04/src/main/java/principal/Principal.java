
package principal;

import view.FrmMenuMain;

public class Principal {

    public static void main(String[] args) {
       FrmMenuMain tela = new  FrmMenuMain();
       tela.setVisible(true);
    }
}
