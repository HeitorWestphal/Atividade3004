package view;

public class Mensagens extends Exception {

    Mensagens(String msg) {
        super(msg);
    }
}
